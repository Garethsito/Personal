package ej10;

public class tablero {
    fo
}
