// Source code is decompiled from a .class file using FernFlower decompiler.
public class nodo 
{
   private int Elem;
   private nodo der;
   private nodo izq;


   public int getElem() { return Elem; }
   public void setElem(int elem) {Elem = elem;}

   public nodo getDer() {return der;}
   public void setDer(nodo der) {this.der = der;}

   public nodo getIzq() {return izq;}
   public void setIzq(nodo izq) {this.izq = izq;}

   

} 