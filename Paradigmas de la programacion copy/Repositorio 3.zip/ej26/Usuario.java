public interface Usuario {
    void crearUsuario();
    void borrarUsuario();

}
