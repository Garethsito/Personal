interface MyInterface2 {
    //public void prueba(String dato){}
    public String prueba2(String dato);
}
