public interface MyInterface {
    public void saludo();
}
