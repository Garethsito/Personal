% comentario hola mundo
% relaciones(argumento u objeto)
es_perro(firulais).
es_gato(garfield).
es_mascota(solovino, blackio, micha).