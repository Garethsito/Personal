public abstract class Figura {



    
}
