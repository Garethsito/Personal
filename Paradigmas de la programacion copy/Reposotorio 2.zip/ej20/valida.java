package ej20;

public class valida {
    public static boolean soloXO(String dato){
        return dato.matches(".*[XO].*");
    }


}
